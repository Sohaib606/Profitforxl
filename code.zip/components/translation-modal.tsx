"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"

interface WordData {
  word: string
  usage_in_article: string
  simple_english_meaning: string
  synonyms: string[]
  english_example: string
  urdu_meaning: string
  urdu_sentence: string
  pashto: string
  punjabi: string
  sindhi: string
  balochi?: string
}

interface TranslationModalProps {
  word: WordData | null
  onClose: () => void
}

export function TranslationModal({ word, onClose }: TranslationModalProps) {
  const [isSpeaking, setIsSpeaking] = useState<string | null>(null)

  if (!word) return null

  const handleSpeak = (text: string, language: string) => {
    if (isSpeaking === language) {
      window.speechSynthesis.cancel()
      setIsSpeaking(null)
      return
    }

    window.speechSynthesis.cancel()
    const utterance = new SpeechSynthesisUtterance(text)

    const languageMap: Record<string, string> = {
      english: "en-US",
      urdu: "ur-PK",
      pashto: "ps-AF",
      punjabi: "pa-IN",
      sindhi: "sd-PK",
    }

    utterance.lang = languageMap[language] || "en-US"
    utterance.rate = 0.9
    utterance.pitch = 1

    utterance.onend = () => setIsSpeaking(null)
    utterance.onerror = () => setIsSpeaking(null)

    setIsSpeaking(language)
    window.speechSynthesis.speak(utterance)
  }

  return (
    <AnimatePresence>
      <>
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/50 z-40"
        />

        {/* Modal */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="fixed inset-4 md:inset-auto md:left-1/2 md:top-1/2 md:transform md:-translate-x-1/2 md:-translate-y-1/2 md:max-w-2xl bg-card rounded-lg border border-border shadow-xl p-6 md:p-8 z-50 overflow-y-auto max-h-[90vh] md:max-h-[80vh]"
        >
          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-muted-foreground hover:text-foreground transition text-2xl"
          >
            ×
          </button>

          {/* Title */}
          <h2 className="text-4xl font-bold text-primary mb-2">{word.word}</h2>

          <div className="mb-6">
            <p className="text-sm text-muted-foreground italic mb-2">"{word.usage_in_article}"</p>
            {word.synonyms && word.synonyms.length > 0 && (
              <p className="text-sm text-muted-foreground">
                <span className="font-semibold">Synonyms:</span> {word.synonyms.join(", ")}
              </p>
            )}
          </div>

          {/* Translations Grid */}
          <div className="space-y-6">
            {/* English */}
            <div className="border-l-4 border-primary pl-4">
              <div className="flex items-center gap-2 mb-2">
                <h3 className="text-lg font-semibold text-foreground">🇬🇧 English</h3>
                <button
                  onClick={() =>
                    handleSpeak(
                      `${word.word}. ${word.simple_english_meaning}. Example: ${word.english_example}`,
                      "english",
                    )
                  }
                  className={`text-xl transition ${isSpeaking === "english" ? "text-primary scale-110" : "text-muted-foreground hover:text-primary"}`}
                  title="Speak English"
                >
                  🔊
                </button>
              </div>
              <p className="text-foreground mb-3">{word.simple_english_meaning}</p>
              <div className="bg-secondary/30 rounded p-3">
                <p className="text-sm text-muted-foreground italic">Example:</p>
                <p className="text-foreground">"{word.english_example}"</p>
              </div>
            </div>

            {/* Urdu */}
            <div className="border-l-4 border-accent pl-4">
              <div className="flex items-center gap-2 mb-2">
                <h3 className="text-lg font-semibold text-foreground">🇵🇰 Urdu</h3>
                <button
                  onClick={() => handleSpeak(`${word.word}. ${word.urdu_meaning}. مثال: ${word.urdu_sentence}`, "urdu")}
                  className={`text-xl transition ${isSpeaking === "urdu" ? "text-primary scale-110" : "text-muted-foreground hover:text-primary"}`}
                  title="Speak Urdu"
                >
                  🔊
                </button>
              </div>
              <p className="text-foreground text-2xl mb-3 font-semibold">{word.urdu_meaning}</p>
              <div className="bg-secondary/30 rounded p-3">
                <p className="text-sm text-muted-foreground italic">مثال:</p>
                <p className="text-foreground text-lg">{word.urdu_sentence}</p>
              </div>
            </div>

            {/* Pashto */}
            <div className="border-l-4 border-muted pl-4">
              <div className="flex items-center gap-2 mb-2">
                <h3 className="text-lg font-semibold text-foreground">🇦🇫 Pashto</h3>
                <button
                  onClick={() => handleSpeak(word.pashto, "pashto")}
                  className={`text-xl transition ${isSpeaking === "pashto" ? "text-primary scale-110" : "text-muted-foreground hover:text-primary"}`}
                  title="Speak Pashto"
                >
                  🔊
                </button>
              </div>
              <p className="text-foreground text-xl">{word.pashto}</p>
            </div>

            {/* Punjabi */}
            <div className="border-l-4 border-muted pl-4">
              <div className="flex items-center gap-2 mb-2">
                <h3 className="text-lg font-semibold text-foreground">🇮🇳 Punjabi</h3>
                <button
                  onClick={() => handleSpeak(word.punjabi, "punjabi")}
                  className={`text-xl transition ${isSpeaking === "punjabi" ? "text-primary scale-110" : "text-muted-foreground hover:text-primary"}`}
                  title="Speak Punjabi"
                >
                  🔊
                </button>
              </div>
              <p className="text-foreground text-xl">{word.punjabi}</p>
            </div>

            {/* Sindhi */}
            <div className="border-l-4 border-muted pl-4">
              <div className="flex items-center gap-2 mb-2">
                <h3 className="text-lg font-semibold text-foreground">Sindhi</h3>
                <button
                  onClick={() => handleSpeak(word.sindhi, "sindhi")}
                  className={`text-xl transition ${isSpeaking === "sindhi" ? "text-primary scale-110" : "text-muted-foreground hover:text-primary"}`}
                  title="Speak Sindhi"
                >
                  🔊
                </button>
              </div>
              <p className="text-foreground text-xl">{word.sindhi}</p>
            </div>

            {/* Balochi - if available */}
            {word.balochi && (
              <div className="border-l-4 border-muted pl-4">
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="text-lg font-semibold text-foreground">Balochi</h3>
                  <button
                    onClick={() => handleSpeak(word.balochi!, "english")}
                    className={`text-xl transition ${isSpeaking === "english" ? "text-primary scale-110" : "text-muted-foreground hover:text-primary"}`}
                    title="Speak Balochi"
                  >
                    🔊
                  </button>
                </div>
                <p className="text-foreground text-xl">{word.balochi}</p>
              </div>
            )}
          </div>
        </motion.div>
      </>
    </AnimatePresence>
  )
}

export default TranslationModal
