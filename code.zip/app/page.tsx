"use client"

import { useRouter } from "next/navigation"
import { motion } from "framer-motion"

export default function Home() {
  const router = useRouter()

  const newspapers = [
    {
      id: "dawn",
      name: "Dawn News",
      description: "Pakistan's leading English newspaper",
      icon: "📰",
    },
  ]

  return (
    <main className="min-h-screen bg-background flex flex-col items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center max-w-2xl"
      >
        <h1 className="text-6xl font-bold text-foreground mb-3">DawnMuse</h1>
        <p className="text-xl text-muted-foreground mb-12">Discover the meanings behind the news</p>

        <div className="space-y-4">
          {newspapers.map((paper) => (
            <motion.button
              key={paper.id}
              onClick={() => router.push(`/newspapers/${paper.id}/months`)}
              whileHover={{ scale: 1.02, y: -5 }}
              whileTap={{ scale: 0.98 }}
              className="w-full p-8 bg-card rounded-lg border border-border hover:border-primary/50 transition-all hover:shadow-lg"
            >
              <div className="text-3xl mb-3">{paper.icon}</div>
              <h2 className="text-2xl font-semibold text-foreground mb-2">{paper.name}</h2>
              <p className="text-muted-foreground">{paper.description}</p>
            </motion.button>
          ))}
        </div>
      </motion.div>
    </main>
  )
}
