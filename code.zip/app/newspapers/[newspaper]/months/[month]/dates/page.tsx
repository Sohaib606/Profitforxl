"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { motion } from "framer-motion"
import Link from "next/link"

export default function DatesPage() {
  const params = useParams()
  const router = useRouter()
  const [dates, setDates] = useState<string[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadDates = async () => {
      try {
        const month = params.month as string
        const year = Number.parseInt(month.split("-")[0])
        const monthNum = Number.parseInt(month.split("-")[1])

        // Generate dates for this month
        const daysInMonth = new Date(year, monthNum, 0).getDate()
        const monthDates: string[] = []

        for (let i = 1; i <= daysInMonth; i++) {
          const day = String(i).padStart(2, "0")
          monthDates.push(`${month}-${day}`)
        }

        // Reverse to show most recent first
        setDates(monthDates.reverse())
      } catch (error) {
        console.error("Error loading dates:", error)
      } finally {
        setLoading(false)
      }
    }

    loadDates()
  }, [params.month])

  return (
    <main className="min-h-screen bg-background p-6">
      <div className="max-w-4xl mx-auto">
        <Link
          href={`/newspapers/${params.newspaper}/months`}
          className="inline-flex items-center text-primary hover:text-primary/80 mb-8 transition"
        >
          ← Back to Months
        </Link>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl font-bold text-foreground mb-2"
        >
          Select Date
        </motion.h1>
        <p className="text-muted-foreground mb-12">Choose a publication date to explore</p>

        {loading ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Loading dates...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {dates.map((date, idx) => (
              <motion.button
                key={date}
                onClick={() =>
                  router.push(`/newspapers/${params.newspaper}/months/${params.month}/dates/${date}/categories`)
                }
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="p-6 bg-card rounded-lg border border-border hover:border-primary/50 hover:shadow-md transition-all"
              >
                <p className="text-lg font-semibold text-foreground">
                  {new Date(date).toLocaleDateString("en-US", {
                    weekday: "long",
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                </p>
              </motion.button>
            ))}
          </div>
        )}
      </div>
    </main>
  )
}
