"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { motion } from "framer-motion"
import Link from "next/link"

export default function CategoriesPage() {
  const params = useParams()
  const router = useRouter()
  const [categories, setCategories] = useState<string[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadCategories = async () => {
      try {
        setCategories([
          "Frontpage",
          "National 1",
          "National 2",
          "National 3",
          "Editorial",
          "Opinion",
          "National 4",
          "Business",
          "International 1",
          "International 2",
          "Backpage",
          "Sports 1",
          "Sports 2",
        ])
      } catch (error) {
        console.error("Error loading categories:", error)
      } finally {
        setLoading(false)
      }
    }

    loadCategories()
  }, [params.date])

  const getCategorySlug = (category: string) => category.toLowerCase().replace(/\s+/g, "-")

  return (
    <main className="min-h-screen bg-background p-6">
      <div className="max-w-4xl mx-auto">
        <Link
          href={`/newspapers/${params.newspaper}/months/${params.month}/dates`}
          className="inline-flex items-center text-primary hover:text-primary/80 mb-8 transition"
        >
          ← Back to Dates
        </Link>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl font-bold text-foreground mb-2"
        >
          Select Category
        </motion.h1>
        <p className="text-muted-foreground mb-12">Choose an article category for {params.date}</p>

        {loading ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Loading categories...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {categories.map((category, idx) => (
              <motion.button
                key={category}
                onClick={() =>
                  router.push(
                    `/newspapers/${params.newspaper}/months/${params.month}/dates/${params.date}/categories/${getCategorySlug(category)}/viewer`,
                  )
                }
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="p-8 bg-card rounded-lg border border-border hover:border-primary/50 hover:shadow-md transition-all"
              >
                <p className="text-xl font-semibold text-foreground">{category}</p>
              </motion.button>
            ))}
          </div>
        )}
      </div>
    </main>
  )
}
