"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import Link from "next/link"
import { motion } from "framer-motion"

interface Article {
  article_title: string
  part1: {
    vocabulary: Array<{
      word: string
    }>
  }
}

export default function ArticlesPage() {
  const params = useParams()
  const [articles, setArticles] = useState<Article[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadArticles = async () => {
      try {
        const sampleArticles: Article[] = [
          {
            article_title: "Govt issues fresh call for Afghans to leave",
            part1: {
              vocabulary: [
                { word: "issues" },
                { word: "fresh" },
                { word: "call" },
                { word: "living" },
                { word: "leave" },
                { word: "triggering" },
                { word: "thousands" },
                { word: "rush" },
                { word: "border" },
                { word: "officials" },
                { word: "received" },
                { word: "directives" },
                { word: "home department" },
                { word: "launch" },
                { word: "drive" },
                { word: "repatriate" },
                { word: "respectful" },
                { word: "orderly" },
                { word: "manner" },
                { word: "senior" },
                { word: "capital" },
                { word: "province" },
                { word: "told" },
                { word: "around" },
                { word: "waiting" },
                { word: "head" },
                { word: "refugee registration" },
                { word: "across" },
                { word: "aware" },
                { word: "increase" },
                { word: "returning" },
                { word: "poured" },
                { word: "past" },
                { word: "several" },
                { word: "decades" },
                { word: "fleeing" },
                { word: "successive" },
                { word: "wars" },
                { word: "arrived" },
                { word: "return" },
                { word: "deportation" },
                { word: "first" },
                { word: "launched" },
                { word: "renewed" },
                { word: "rescinded" },
                { word: "residence permits" },
                { word: "warning" },
                { word: "arrests" },
                { word: "analysts" },
                { word: "expulsions" },
                { word: "designed" },
                { word: "pressure" },
                { word: "authorities" },
              ],
            },
          },
        ]
        setArticles(sampleArticles)
      } catch (error) {
        console.error("Error loading articles:", error)
      } finally {
        setLoading(false)
      }
    }

    loadArticles()
  }, [params.category])

  const categoryDisplay = Array.isArray(params.category) ? params.category[params.category.length - 1] : params.category

  return (
    <main className="min-h-screen bg-background flex flex-col">
      <div className="p-4 border-b border-border">
        <Link
          href={`/newspapers/${params.newspaper}/months/${params.month}/dates/${params.date}/categories`}
          className="inline-flex items-center text-primary hover:text-primary/80 transition"
        >
          ← Back to Categories
        </Link>
      </div>

      <div className="p-6">
        <h1 className="text-3xl font-bold text-foreground mb-2">{categoryDisplay}</h1>
        <p className="text-muted-foreground mb-6">Select an article to view</p>

        {loading ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Loading articles...</p>
          </div>
        ) : articles.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No articles available in this category.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {articles.map((article, idx) => (
              <Link
                key={article.article_title}
                href={`/newspapers/${params.newspaper}/months/${params.month}/dates/${params.date}/categories/${params.category}/articles/${encodeURIComponent(article.article_title)}/viewer`}
              >
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.98 }}
                  className="p-4 bg-card rounded-lg border border-border hover:border-primary/50 hover:bg-card/80 transition-all cursor-pointer h-full flex flex-col gap-2"
                >
                  <h2 className="font-semibold text-foreground text-balance">{article.article_title}</h2>
                  <p className="text-sm text-muted-foreground">{article.part1.vocabulary.length} vocabulary items</p>
                </motion.div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </main>
  )
}
