"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { useParams } from "next/navigation"
import { motion } from "framer-motion"
import Link from "next/link"
import { TranslationModal } from "@/components/translation-modal"

interface WordData {
  word: string
  usage_in_article: string
  simple_english_meaning: string
  synonyms: string[]
  english_example: string
  urdu_meaning: string
  urdu_sentence: string
  pashto: string
  punjabi: string
  sindhi: string
  balochi?: string
}

interface ArticleData {
  article_title: string
  part1: {
    vocabulary: WordData[]
  }
}

export default function ViewerPage() {
  const params = useParams()
  const [words, setWords] = useState<WordData[]>([])
  const [selectedWord, setSelectedWord] = useState<WordData | null>(null)
  const [loading, setLoading] = useState(true)
  const [imageUrl, setImageUrl] = useState(
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/02_08_2025_001_001-NC3u3qgY4t7qht2GdLZtrEVjqvzylW.jpg",
  )
  const [articleTitle, setArticleTitle] = useState("")
  const [zoomLevel, setZoomLevel] = useState(1)
  const [position, setPosition] = useState({ x: 0, y: 0 })
  const [isDragging, setIsDragging] = useState(false)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })
  const [touchDistance, setTouchDistance] = useState(0)
  const [isTouchDragging, setIsTouchDragging] = useState(false)
  const [touchDragStart, setTouchDragStart] = useState({ x: 0, y: 0 })
  const [dragSpeed, setDragSpeed] = useState(1)
  const imageContainerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const loadData = async () => {
      try {
        const completeArticleData: ArticleData = {
          article_title: "Govt issues fresh call for Afghans to leave",
          part1: {
            vocabulary: [
              {
                word: "issues",
                usage_in_article: "Govt issues fresh call...",
                simple_english_meaning:
                  "To formally send out or announce something, like a warning, statement, or command.",
                synonyms: ["releases", "publishes", "announces"],
                english_example: "The central bank issues new currency notes every few years.",
                urdu_meaning: "Jari Karna (جاری کرنا), Hukm Nama Jari Karna (حکم نامہ جاری کرنا)",
                urdu_sentence:
                  "Hukumat nai afghano ko mulk chornay kay liye naya hukm nama jari kiya hai. (حکومت نے افغانوں کو ملک چھوڑنے کے لیے نیا حکم نامہ جاری کیا ہے۔)",
                pashto: "Khparawul (خپرول)",
                punjabi: "Jari Karna (جاری کرنا)",
                sindhi: "Jari Karan (جاري ڪرڻ)",
                balochi: "Shuroo Kangan (شروع کنگن)",
              },
              {
                word: "fresh",
                usage_in_article: "Govt issues fresh call...",
                simple_english_meaning: "New or different, in addition to what has existed before.",
                synonyms: ["new", "additional", "latest"],
                english_example: "The government announced a fresh set of economic reforms.",
                urdu_meaning: "Naya (نیا), Taza (تازہ)",
                urdu_sentence:
                  "Aik taza muhim jald hi mulk bhar mein shuru ki jaye gi. (ایک تازہ مہم جلد ہی ملک بھر میں شروع کی جائے گی۔)",
                pashto: "Nawae (نوی)",
                punjabi: "Nawan (نواں)",
                sindhi: "Naoon (نئون)",
                balochi: "Nok (نوک)",
              },
              {
                word: "call",
                usage_in_article: "Govt issues fresh call for Afghans to leave...",
                simple_english_meaning: "A formal public request or command.",
                synonyms: ["demand", "appeal", "directive"],
                english_example: "The environmental group issued a call for immediate action.",
                urdu_meaning: "Mutalba (مطالبہ), Hukm (حکم), Daawat (دعوت)",
                urdu_sentence:
                  "Wazarat-e-Dakhila nai shehriyon sai razakarana tor par mulk chornay ka mutalba kiya hai. (وزارت داخلہ نے شہریوں سے رضاکارانہ طور پر ملک چھوڑنے کا مطالبہ کیا ہے۔)",
                pashto: "Ghoṣtana (غوષتنه)",
                punjabi: "Mang (منگ)",
                sindhi: "Sadd (سڏ)",
                balochi: "Talab (طلب)",
              },
              {
                word: "living",
                usage_in_article: "Afghans living in the southwest...",
                simple_english_meaning: "Residing or currently staying in a specific place.",
                synonyms: ["residing", "dwelling", "staying"],
                english_example: "The family is currently living in a rented apartment.",
                urdu_meaning: "Reh rahay (رہ رہے), Muqeem (مقیم)",
                urdu_sentence:
                  "Janobi-maghrib mein rehnay walay afghanon ko mulk chorna ho ga. (جنوبی مغرب میں رہ رہے افغانوں کو ملک چھوڑنا ہو گا۔)",
                pashto: "Osaydalo (اوسیدل)",
                punjabi: "Rai Ray (رہ رہے)",
                sindhi: "Rahindarr (رهندڙ)",
                balochi: "Nishtag (نشتگ)",
              },
              {
                word: "leave",
                usage_in_article: "call for Afghans to leave the country...",
                simple_english_meaning: "To go away from a place; to depart.",
                synonyms: ["depart", "exit", "vacate"],
                english_example: "They were given one week to leave the premises.",
                urdu_meaning: "Chhorna (چھوڑنا), Rukhsat hona (رخصت ہونا)",
                urdu_sentence:
                  "Hukumat nai afghano ko mulk chornay ko kaha hai. (حکومت نے افغانوں کو ملک چھوڑنے کو کہا ہے۔)",
                pashto: "Watal (وتل)",
                punjabi: "Chor Jana (چھوڑ جانا)",
                sindhi: "Chhadey Vajan (ڇڏي وڃڻ)",
                balochi: "Rāh Kanan (راہ کنان)",
              },
              {
                word: "triggering",
                usage_in_article: "triggering thousands to rush to the border...",
                simple_english_meaning: "Causing an event or situation to happen or begin.",
                synonyms: ["causing", "initiating", "provoking"],
                english_example: "The announcement of new taxes is triggering public protests.",
                urdu_meaning: "Ki Wajah Banna (کی وجہ بننا), Mutaharik Karna (متحرک کرنا)",
                urdu_sentence:
                  "Hukm nama nai logon kay hujoom ko sarhad par mutaharik kar diya. (حکم نامہ نے لوگوں کے ہجوم کو سرحد پر متحرک کر دیا)",
                pashto: "Pah Kar Āchawul (په کار اچول)",
                punjabi: "Chalu Karna (چالو کرنا)",
                sindhi: "Jōsh Diyaran (جوش ڏيارڻ)",
                balochi: "Pālī Kangan (پالي کنگن)",
              },
              {
                word: "thousands",
                usage_in_article: "triggering thousands to rush to the border...",
                simple_english_meaning: "A large, indefinite number of people (or things), a very large amount.",
                synonyms: ["multitude", "legions", "masses"],
                english_example: "Thousands of supporters attended the political rally.",
                urdu_meaning: "Hazaron (ہزاروں), Bohat Bari Tadaad (بہت بڑی تعداد)",
                urdu_sentence:
                  "Hazarron afghan sarhad ki taraf bhag rahay hain. (ہزاروں افغان سرحد کی طرف بھاگ رہے ہیں۔)",
                pashto: "Zaruna (زرونه)",
                punjabi: "Hazaraan (ہزاراں)",
                sindhi: "Hazāran (هزارن)",
                balochi: "Hāzārān (ہزاران)",
              },
              {
                word: "rush",
                usage_in_article: "thousands to rush to the border...",
                simple_english_meaning: "To move or act with urgent haste; to hurry.",
                synonyms: ["hurry", "hasten", "flee"],
                english_example: "The students had to rush to catch the last bus.",
                urdu_meaning: "Jaldi Karna (جلدی کرنا), Tezi sai jana (تیزی سے جانا)",
                urdu_sentence:
                  "Hazarron afghan sarhad ki taraf tezi sai jaa rahay hain. (ہزاروں افغان سرحد کی طرف تیزی سے جا رہے ہیں۔)",
                pashto: "Beṛa Kawul (بېړه کول)",
                punjabi: "Jaldi Karna (جلدی کرنا)",
                sindhi: "Jaldi Karan (جلدي ڪرڻ)",
                balochi: "Jaldi Kangan (جلدی کنگن)",
              },
              {
                word: "border",
                usage_in_article: "to rush to the border...",
                simple_english_meaning: "The line that separates two countries, states, or regions.",
                synonyms: ["frontier", "boundary", "line"],
                english_example: "The soldiers patrolled the national border day and night.",
                urdu_meaning: "Sarhad (سرحد), Simaat (سرحد)",
                urdu_sentence:
                  "Log Afghanistan ki sarhad ki taraf bhag rahay hain. (لوگ افغانستان کی سرحد کی طرف بھاگ رہے ہیں۔)",
                pashto: "Sarhad (سرحد)",
                punjabi: "Sarhad (سرحد)",
                sindhi: "Sarhad (سرحد)",
                balochi: "Sarhad (سرحد)",
              },
              {
                word: "officials",
                usage_in_article: "officials said.",
                simple_english_meaning:
                  "People who hold a public office or are in a position of authority, especially in the government.",
                synonyms: ["administrators", "authorities", "executives"],
                english_example: "Government officials met to discuss the new housing policy.",
                urdu_meaning: "Ahalkaar (اہلکار), Afsaraan (افسران)",
                urdu_sentence:
                  "Sarhad par mojood hukam nai logon ki bari tadaad ki tasdeeq ki hai. (سرحد پر موجود حکام نے لوگوں کی بڑی تعداد کی تصدیق کی ہے۔)",
                pashto: "Chārwāki (چارواکي)",
                punjabi: "Adhikari (ادھیکاری)",
                sindhi: "Sarkari Amaldaar (سرڪاري عملدار)",
                balochi: "Afsharān (افسران)",
              },
              {
                word: "received",
                usage_in_article: '"We have received directives...',
                simple_english_meaning: "To be given or to get something.",
                synonyms: ["got", "obtained", "acquired"],
                english_example: "The manager received the report this morning.",
                urdu_meaning: "Mousool kiye (موصول کیے), Milay (ملے)",
                urdu_sentence:
                  "Humain wazarat-e-dakhila sai nayi hadayat mousool hui hain. (ہمیں وزارت داخلہ سے نئی ہدایات موصول ہوئی ہیں۔)",
                pashto: "Lāsa Katay (لاس کړي)",
                punjabi: "Mileya (ملیا)",
                sindhi: "Hāsil Kayo (حاصل ڪيو)",
                balochi: "Rāsā Kangan (رسا کنگن)",
              },
              {
                word: "directives",
                usage_in_article: '"We have received directives from the home department...',
                simple_english_meaning: "Formal instructions or orders from an authoritative source.",
                synonyms: ["orders", "instructions", "commands"],
                english_example: "The CEO issued clear directives on how to proceed with the merger.",
                urdu_meaning: "Hadayat (ہدایات), Ahkaam (احکام)",
                urdu_sentence:
                  "Humain mahkama-e-dakhila sai afghano ko mulk badar karnay kay baray mein hadayat mousool hui hain. (ہمیں محکمۂ داخلہ سے افغانوں کو ملک بدر کرنے کے بارے میں ہدایات موصول ہوئی ہیں۔)",
                pashto: "Lārshawnai (لارښوونې)",
                punjabi: "Nirdesh (نردیش)",
                sindhi: "Hukm Nāma (حڪم ناما)",
                balochi: "Hidayat Nāmag (ہدایت نامگ)",
              },
              {
                word: "home department",
                usage_in_article: "directives from the home department...",
                simple_english_meaning:
                  "A government agency responsible for internal security, borders, and immigration matters.",
                synonyms: ["interior ministry", "internal security agency", "local administration"],
                english_example: "The home department issued a travel advisory for the region.",
                urdu_meaning: "Mahkama-e-Dakhila (محکمۂ داخلہ), Wazarat-e-Dakhila (وزارت داخلہ)",
                urdu_sentence:
                  "Mahkama-e-Dakhila nai nai visas jari karnay sai inkar kar diya. (محکمۂ داخلہ نے نئے ویزے جاری کرنے سے انکار کر دیا)",
                pashto: "Dākhila Wizārat (داخله وزارت)",
                punjabi: "Gharelu Mahkma (گھریلو محکمہ)",
                sindhi: "Dakhila Khatō (داخله کاتو)",
                balochi: "Dākhili Mahkama (داخلی محکمہ)",
              },
              {
                word: "launch",
                usage_in_article: "to launch a fresh drive to repatriate all Afghans...",
                simple_english_meaning: "To start or set in motion a new campaign or initiative.",
                synonyms: ["begin", "start", "initiate"],
                english_example: "The charity plans to launch a major fundraising campaign next month.",
                urdu_meaning: "Shuru Karna (شروع کرنا), Aaghaz Karna (آغاز کرنا)",
                urdu_sentence:
                  "Hukumat nai ghair qanooni tārkin-e-watan ki watan wapsi kay liye aik nayi muhim shuru ki hai. (حکومت نے غیر قانونی تارکین وطن کی وطن واپسی کے لیے ایک نئی مہم شروع کی ہے۔)",
                pashto: "Pīl Kawul (پیل کول)",
                punjabi: "Shuru Karna (شروع کرنا)",
                sindhi: "Shuru Karan (شروع ڪرڻ)",
                balochi: "Bandag (بندگ)",
              },
              {
                word: "drive",
                usage_in_article: "to launch a fresh drive to repatriate all Afghans...",
                simple_english_meaning: "A concerted and determined effort or campaign toward a specific goal.",
                synonyms: ["campaign", "effort", "initiative"],
                english_example: "The city council started a drive to clean up the local parks.",
                urdu_meaning: "Muhim (مہم), Koshish (کوشش)",
                urdu_sentence:
                  "Mulk badri ki muhim pichlay saal shuru ki gayi thi. (ملک بدری کی مہم پچھلے سال شروع کی گئی تھی۔)",
                pashto: "Kampā'īn (کمپاین)",
                punjabi: "Muhim (مہم)",
                sindhi: "Muhim (مهم)",
                balochi: "Jast o Jū (جست و جو)",
              },
              {
                word: "repatriate",
                usage_in_article: "to launch a fresh drive to repatriate all Afghans...",
                simple_english_meaning: "To send or bring someone (or something) back to their own country.",
                synonyms: ["deport", "send back", "return"],
                english_example: "The government is making plans to repatriate its citizens from the war zone.",
                urdu_meaning: "Watan wapas bhaijna (وطن واپس بھیجنا), Mulk Badar Karna (ملک بدر کرنا)",
                urdu_sentence:
                  "Hukam ko tamam ghair qanooni afghano ko unkay watan wapas bhaijnay ki hadayat ki gayi hai. (حکام کو تمام غیر قانونی افغانوں کو ان کے وطن واپس بھیجنے کی ہدایت کی گئی ہے۔)",
                pashto: "Hīwād ta Garzawul (هیواد ته ګرځول)",
                punjabi: "Desh Wapas Bhejna (دیش واپس بھیجنا)",
                sindhi: "Mulki Wapas Mōkalan (ملڪ واپس موڪلڻ)",
                balochi: "Watī Watan Wāpas Kangan (وتی وطن واپس کنگن)",
              },
              {
                word: "respectful",
                usage_in_article: "in a respectful and orderly manner",
                simple_english_meaning: "Showing or feeling deference and high regard for someone or something.",
                synonyms: ["polite", "courteous", "civil"],
                english_example: "The staff treated all the customers in a respectful manner.",
                urdu_meaning: "Ba-waqaar (باوقار), Izzatdaar (عزت دار)",
                urdu_sentence:
                  "Afghano ko ba-waqar aur munazzam tareeqay sai wapas bhaija jaye ga. (افغانوں کو باوقار اور منظم طریقے سے واپس بھیجا جائے گا۔)",
                pashto: "Bā 'Izzata (با عزته)",
                punjabi: "Izzatdār (عزت دار)",
                sindhi: "Izzatdar (عزت دار)",
                balochi: "Ba 'Izzat (با عزت)",
              },
              {
                word: "orderly",
                usage_in_article: "in a respectful and orderly manner",
                simple_english_meaning: "Arranged or done in a systematic, neat, or controlled way.",
                synonyms: ["organized", "structured", "controlled"],
                english_example: "The crowd left the stadium in a calm and orderly fashion.",
                urdu_meaning: "Ba-qa'ida (باقاعدہ), Munazzam (منظم)",
                urdu_sentence:
                  "Logn nai pur-sakoon aur munazzam andaz mein jaga chhor di. (لوگوں نے پرسکون اور منظم انداز میں جگہ چھوڑ دی۔)",
                pashto: "Munazzam (منظم)",
                punjabi: "Tartibwār (ترتیب وار)",
                sindhi: "Munazzam (منظم)",
                balochi: "Munazzam (منظم)",
              },
              {
                word: "manner",
                usage_in_article: "in a respectful and orderly manner",
                simple_english_meaning: "A way in which a thing is done or happens.",
                synonyms: ["way", "method", "style"],
                english_example: "She handled the difficult situation in a professional manner.",
                urdu_meaning: "Tareeqa (طریقہ), Andaaz (انداز)",
                urdu_sentence:
                  "Hukam nai is maslay ko aik munazzam tareeqa sai hal kiya. (حکام نے اس مسئلے کو ایک منظم طریقے سے حل کیا۔)",
                pashto: "Tarīqa (طريقه)",
                punjabi: "Tareeqa (طریقہ)",
                sindhi: "Tariqo (طريقو)",
                balochi: "Rāh (راہ)",
              },
              {
                word: "senior",
                usage_in_article: "a senior government official in Quetta...",
                simple_english_meaning: "High in rank or status; experienced and authoritative.",
                synonyms: ["high-ranking", "top", "experienced"],
                english_example: "A senior executive will be appointed to lead the new division.",
                urdu_meaning: "Aala (اعلیٰ), Badey (بڑے), Buzurg (بزرگ)",
                urdu_sentence: "Aik aala sarkaari afsar nai elaan kiya. (ایک اعلیٰ سرکاری افسر نے اعلان کیا۔)",
                pashto: "Maśar (مشر)",
                punjabi: "Vadda (وڈّا)",
                sindhi: "Varō (وڏو)",
                balochi: "Sarhēll (سرہیل)",
              },
              {
                word: "capital",
                usage_in_article: "Quetta, the capital of Balochistan province...",
                simple_english_meaning:
                  "The most important city or town of a country or region, usually the seat of government.",
                synonyms: ["main city", "seat of government", "metropolis"],
                english_example: "Islamabad is the capital city of Pakistan.",
                urdu_meaning: "Darul-Hukumat (دارالحکومت), Sadr Maqaam (صدر مقام)",
                urdu_sentence:
                  "Quetta, Balochistan soobay ka darul-hukumat hai. (کوئٹہ، بلوچستان صوبے کا دارالحکومت ہے۔)",
                pashto: "Plāzmaina (پلازمینه)",
                punjabi: "Rajdhani (راج دھانی)",
                sindhi: "Gādi Wari Handh (گادي واري هنڌ)",
                balochi: "Shahar (شہر)",
              },
              {
                word: "province",
                usage_in_article: "the capital of Balochistan province...",
                simple_english_meaning: "A principal administrative division of a country or empire.",
                synonyms: ["state", "region", "territory"],
                english_example: "The area is divided into four administrative provinces.",
                urdu_meaning: "Sooba (صوبہ), Wilayat (ولایت)",
                urdu_sentence:
                  "Balochistan Pakistan ka sab sai bara sooba hai. (بلوچستان پاکستان کا سب سے بڑا صوبہ ہے۔)",
                pashto: "Wilāyat (ولایت)",
                punjabi: "Sooba (صوبہ)",
                sindhi: "Sūbō (صوبو)",
                balochi: "Sooba (صوبہ)",
              },
              {
                word: "told",
                usage_in_article: "province, told AFP.",
                simple_english_meaning: "Past tense of 'tell'; communicated information to someone.",
                synonyms: ["informed", "stated", "related"],
                english_example: "The witness told the police everything they saw.",
                urdu_meaning: "Bataya (بتایا), Kaha (کہا)",
                urdu_sentence:
                  "Afsar nai AFP ko hadayat kay baray mein bataya. (افسر نے اے ایف پی کو ہدایات کے بارے میں بتایا۔)",
                pashto: "Wayal (ویل)",
                punjabi: "Dasya (دسیا)",
                sindhi: "Būdāyō (ٻڌايو)",
                balochi: "Gusht (گشت)",
              },
              {
                word: "around",
                usage_in_article: 'there were "around 4,000 to 5,000 people...',
                simple_english_meaning: "Approximately; roughly.",
                synonyms: ["about", "nearly", "roughly"],
                english_example: "The meeting lasted for around two hours.",
                urdu_meaning: "Taqreeban (تقریباً), Qareeb (قریب)",
                urdu_sentence:
                  "Sarhad par taqreeban 4,000 afghan wapas janay kay intizar mein thay. (سرحد پر تقریباً 4,000 افغان واپس جانے کے انتظار میں تھے۔)",
                pashto: "Nārāhatī (ناراحتي)",
                punjabi: "Lagbhag (لگ بھگ)",
                sindhi: "Lagbhag (لڳ ڀڳ)",
                balochi: "Yakjā (یکجا)",
              },
              {
                word: "waiting",
                usage_in_article: "waiting to return...",
                simple_english_meaning: "Remaining in a place until a particular time or event happens.",
                synonyms: ["expecting", "anticipating", "biding"],
                english_example: "We were waiting for the train to arrive.",
                urdu_meaning: "Intezaar kar rahay (انتظار کر رہے), Muntazir (منتظر)",
                urdu_sentence:
                  "Hazarron afghan wapas janay ka intezaar kar rahay thay. (ہزاروں افغان واپس جانے کا انتظار کر رہے تھے۔)",
                pashto: "Intizār Kawul (انتظار کول)",
                punjabi: "Intizār Kar Rahay (انتظار کر رہے)",
                sindhi: "Intezaar Kande (انتظار ڪندي)",
                balochi: "Intizār Kangan (انتظار کنگن)",
              },
              {
                word: "head",
                usage_in_article: "Abdul Latif Hakimi, the head of Refugee Registration...",
                simple_english_meaning: "The person in charge of an organization or department; the chief or leader.",
                synonyms: ["chief", "director", "leader"],
                english_example: "She was appointed as the head of the marketing team.",
                urdu_meaning: "Sarbarah (سربراہ), Raees (رئیس)",
                urdu_sentence:
                  "Abdul Latif Hakimi Refugee Registration kay sarbarah hain. (عبداللطیف حکیمی ریفیوجی رجسٹریشن کے سربراہ ہیں۔)",
                pashto: "Sarparast (سرپرست)",
                punjabi: "Mukhi (مکھ)",
                sindhi: "Mukhya (مکيه)",
                balochi: "Sarhēll (سرہیل)",
              },
              {
                word: "refugee registration",
                usage_in_article: "the head of Refugee Registration...",
                simple_english_meaning:
                  "The official process of recording and documenting people who have fled their country due to persecution or conflict.",
                synonyms: ["asylum processing", "displaced persons documentation", "migrant enrollment"],
                english_example: "The UNHCR manages the refugee registration process worldwide.",
                urdu_meaning: "Panah Guzin Registration (پناہ گزین رجسٹریشن), Sarparasti ka Indraj (سرپرستی کا اندراج)",
                urdu_sentence:
                  "Panah guzin registration kay sarbarah nai wapas aanay walon ki tadaad mein izafay ka zikar kiya. (پناہ گزین رجسٹریشن کے سربراہ نے واپس آنے والوں کی تعداد میں اضافے کا ذکر کیا)",
                pashto: "D مهاجرینو ثبتول (Muhājirīno Sabtwul)",
                punjabi: "Panah Guzin Register (پناہ گزین رجسٹر)",
                sindhi: "Refugee Registration (ريفيوجي رجسٽريشن)",
                balochi: "Panāh Jōēyandag Rēgistration (پناہ جوئیندگ رجسٹریشن)",
              },
              {
                word: "across",
                usage_in_article: "Kandahar province across the border...",
                simple_english_meaning: "On the opposite side of, or from one side to the other of a line or boundary.",
                synonyms: ["over", "beyond", "on the other side"],
                english_example: "They bought a small house across the river.",
                urdu_meaning: "Paar (پار), Doosri Taraf (دوسری طرف)",
                urdu_sentence:
                  "Kandahar sooba sarhad kay paar Afghanistan mein waqai hai. (قندھار صوبہ سرحد کے پار افغانستان میں واقع ہے۔)",
                pashto: "Hāghō La (هاغو له)",
                punjabi: "Pār (پار)",
                sindhi: "Pār (پار)",
                balochi: "Barz (برز)",
              },
              {
                word: "aware",
                usage_in_article: "said they were aware of an increase in returning Afghans...",
                simple_english_meaning: "Having knowledge or being cognizant of something.",
                synonyms: ["knowledgeable", "informed", "conscious"],
                english_example: "The public became aware of the policy changes only recently.",
                urdu_meaning: "Ba-khabar (باخبر), Aagah (آگاہ)",
                urdu_sentence:
                  "Doosri taraf kay hukam wapas aanay walay afghano ki tadaad mein izafay sai ba-khabar thay. (دوسری طرف کے حکام واپس آنے والے افغانوں کی تعداد میں اضافے سے باخبر تھے۔)",
                pashto: "Khabar Wawul (خبر واوول)",
                punjabi: "Jaanu (جانُو)",
                sindhi: "Aagāh (آگاهہ)",
                balochi: "Sāṛi (ساڑی)",
              },
              {
                word: "increase",
                usage_in_article: "aware of an increase in returning Afghans...",
                simple_english_meaning: "A rise in the amount, size, or number of something.",
                synonyms: ["rise", "growth", "surge"],
                english_example: "The company reported an increase in sales this quarter.",
                urdu_meaning: "Izafa (اضافہ), Barhōtri (بڑھوتری)",
                urdu_sentence:
                  "Wapas aanay walay afghano ki tadaad mein izafa hua hai. (واپس آنے والے افغانوں کی تعداد میں اضافہ ہوا ہے۔)",
                pashto: "Ziyātwālī (زیاتوالی)",
                punjabi: "Izāfa (اضافہ)",
                sindhi: "Wadh (وڌ)",
                balochi: "Ziyād Kangan (زیاد کنگن)",
              },
              {
                word: "returning",
                usage_in_article: "increase in returning Afghans...",
                simple_english_meaning: "Going or coming back to a former place or state.",
                synonyms: ["going back", "reverting", "coming home"],
                english_example: "The ambassador is returning to his post after a brief vacation.",
                urdu_meaning: "Wapas aanay walay (واپس آنے والے), Paltanay walay (پلٹنے والے)",
                urdu_sentence:
                  "Wapas aanay walay afghano ki tadaad mein izafa hua hai. (واپس آنے والے افغانوں کی تعداد میں اضافہ ہوا ہے۔)",
                pashto: "Rāgarzedal (راګرځېدل)",
                punjabi: "Wāpas Āwan (واپس آون)",
                sindhi: "Wapis Achchan (واپس اچڻ)",
                balochi: "Wāpas Āyag (واپس آئیگ)",
              },
              {
                word: "poured",
                usage_in_article: "Afghans have poured into Pakistan...",
                simple_english_meaning:
                  "To move in a large, continuous stream, often used to describe the mass movement of people.",
                synonyms: ["streamed", "flooded", "surged"],
                english_example: "After the concert, the fans poured out of the venue.",
                urdu_meaning: "Ā Jana (آ جانا), Bari Tadaad mein Ana (بڑی تعداد میں آنا)",
                urdu_sentence:
                  "Pichli dahaiyon mein lakhon afghan Pakistan mein aa gaye hain. (پچھلی دہائیوں میں لاکھوں افغان پاکستان میں آ گئے ہیں۔)",
                pashto: "Rāwatal (راوتل)",
                punjabi: "Waddi Ginnti wich Aana (وڈی گنتی وچ آنا)",
                sindhi: "Wade Tadaad mein Āchan (وڏي تعداد ۾ اچڻ)",
                balochi: "Pōr Kangan (پور کنگن)",
              },
              {
                word: "past",
                usage_in_article: "over the past several decades...",
                simple_english_meaning: "Gone by in time; finished.",
                synonyms: ["former", "previous", "gone"],
                english_example: "In the past year, the company's profits have doubled.",
                urdu_meaning: "Guzashta (گزشتہ), Pichla (پچھلا)",
                urdu_sentence:
                  "Guzashta kai dahaiyon mein afghan Pakistan mein aa gaye. (گزشتہ کئی دہائیوں میں افغان پاکستان میں آ گئے۔)",
                pashto: "Tīr (تېر)",
                punjabi: "Pichle (پچھلے)",
                sindhi: "Guzryal (گذرَيل)",
                balochi: "Gud (گد)",
              },
              {
                word: "several",
                usage_in_article: "over the past several decades...",
                simple_english_meaning: "More than two but not many; a handful of.",
                synonyms: ["many", "numerous", "various"],
                english_example: "The scientist conducted several experiments before reaching a conclusion.",
                urdu_meaning: "Kai (کئی), Chand (چند)",
                urdu_sentence:
                  "Pichli kai dahaiyon sai afghan Pakistan mein muqeem hain. (پچھلی کئی دہائیوں سے افغان پاکستان میں مقیم ہیں۔)",
                pashto: "Wārā (وړا)",
                punjabi: "Kai (کئی)",
                sindhi: "Kayi (ڪئي)",
                balochi: "Chund (چند)",
              },
              {
                word: "decades",
                usage_in_article: "over the past several decades...",
                simple_english_meaning: "Periods of ten years.",
                synonyms: ["ten-year periods", "generations", "eras"],
                english_example: "The company has been in business for over three decades.",
                urdu_meaning: "Dahaiyon (دہائیوں), Das Sala Muddat (دس سالہ مدت)",
                urdu_sentence:
                  "Lakhon afghan pichli kai dahaiyon sai Pakistan mein muqeem hain. (لاکھوں افغان پچھلی کئی دہائیوں سے پاکستان میں مقیم ہیں۔)",
                pashto: "Lasīzai (لسیزې)",
                punjabi: "Dahāka (دھاکا)",
                sindhi: "Dahākan (ڏهاڪن)",
                balochi: "Dahak (دهک)",
              },
              {
                word: "fleeing",
                usage_in_article: "fleeing successive wars...",
                simple_english_meaning: "Running away from a place or situation of danger or distress.",
                synonyms: ["escaping", "running away", "evading"],
                english_example: "The villagers were fleeing the area due to heavy fighting.",
                urdu_meaning: "Bhag rahay (بھاگ رہے), Faraar ho rahay (فرار ہو رہے)",
                urdu_sentence:
                  "Woh yakay baad deegaray jangon sai bachanay kay liye Pakistan aaye thay. (وہ یکے بعد دیگرے جنگوں سے بچنے کے لیے پاکستان آئے تھے۔)",
                pashto: "Tāshṭīdal (تښتېدل)",
                punjabi: "Bhajj Rahay (بھج رہے)",
                sindhi: "Bhaji Raha (ڀڄي رها)",
                balochi: "Rāh Kangan (راہ کنگن)",
              },
              {
                word: "successive",
                usage_in_article: "fleeing successive wars...",
                simple_english_meaning: "Following one after the other in sequence.",
                synonyms: ["consecutive", "sequential", "following"],
                english_example: "The team won the championship for three successive years.",
                urdu_meaning: "Yakay Baad Deegaray (یکے بعد دیگرے), Musalsal (مسلسل)",
                urdu_sentence:
                  "Unhon nai yakay baad deegaray jungon ki wajah sai hijrat ki. (انہوں نے یکے بعد دیگرے جنگوں کی وجہ سے ہجرت کی۔)",
                pashto: "Parla Pasī (پرله پسې)",
                punjabi: "Lāgātār (لگاتار)",
                sindhi: "Lagaataar (لڳاتار)",
                balochi: "Pad'a Pad'a (پدءَ پدءَ)",
              },
              {
                word: "wars",
                usage_in_article: "fleeing successive wars...",
                simple_english_meaning: "Periods of sustained, armed conflict between states or organized groups.",
                synonyms: ["conflicts", "fighting", "battle"],
                english_example: "Many families were displaced during the civil wars.",
                urdu_meaning: "Jangain (جنگیں), Laraiyan (لڑائیاں)",
                urdu_sentence:
                  "Afghanistan mein musalsal jangon ki wajah sai log wahan sai niklay. (افغانستان میں مسلسل جنگوں کی وجہ سے لوگ وہاں سے نکلے۔)",
                pashto: "Janguna (جنګونه)",
                punjabi: "Jangaan (جنگاں)",
                sindhi: "Janguoon (جنگئون)",
                balochi: "Jangān (جنگان)",
              },
              {
                word: "arrived",
                usage_in_article: "hundreds of thousands who arrived after the return...",
                simple_english_meaning: "Reached a place at the end of a journey or a period of waiting.",
                synonyms: ["reached", "came", "got there"],
                english_example: "The plane arrived at the airport on time.",
                urdu_meaning: "Pohanchay (پہنچے), Aaey (آئے)",
                urdu_sentence:
                  "Taliban hukumat ki wapsi kay baad kai lakh afghan Pakistan pohanchay. (طالبان حکومت کی واپسی کے بعد کئی لاکھ افغان پاکستان پہنچے۔)",
                pashto: "Rāghlal (راغلل)",
                punjabi: "Aaye (آئے)",
                sindhi: "Āya (آيا)",
                balochi: "Āt (آت)",
              },
              {
                word: "return",
                usage_in_article: "after the return of the Taliban government...",
                simple_english_meaning: "The action of coming or going back to a previous place or condition.",
                synonyms: ["comeback", "re-establishment", "reversion"],
                english_example: "The team celebrated the return of their star player.",
                urdu_meaning: "Wapsi (واپسی), Paltna (پلٹنا)",
                urdu_sentence:
                  "Taliban hukumat ki wapsi kay baad afghan Pakistan aaye. (طالبان حکومت کی واپسی کے بعد افغان پاکستان آئے۔)",
                pashto: "Rāgarzedal (راګرځېدل)",
                punjabi: "Wapsi (واپسی)",
                sindhi: "Wapsi (واپسي)",
                balochi: "Wāpasī (واپسی)",
              },
              {
                word: "deportation",
                usage_in_article: "A deportation drive first launched in 2023...",
                simple_english_meaning:
                  "The official removal of an alien from a country, especially on the grounds of illegal status.",
                synonyms: ["expulsion", "repatriation", "banishment"],
                english_example: "The government ordered the deportation of all undocumented workers.",
                urdu_meaning: "Mulk Badri (ملک بدری), Ikhraj (اخراج)",
                urdu_sentence:
                  "Afghanon ki mulk badri ki muhim ka dobara aaghaz kiya gaya. (افغانوں کی ملک بدری کی مہم کا دوبارہ آغاز کیا گیا۔)",
                pashto: "La Hīwāda Īstal (له هېواده ایستل)",
                punjabi: "Desh Nikala (دیش نکالہ)",
                sindhi: "Mulki Nikāli (ملڪي نيڪالي)",
                balochi: "Dar Kangan (در کنگن)",
              },
              {
                word: "first",
                usage_in_article: "A deportation drive first launched in 2023...",
                simple_english_meaning: "Coming before all others in time or order.",
                synonyms: ["initial", "earliest", "original"],
                english_example: "He was the first person to cross the finish line.",
                urdu_meaning: "Sab sai pehlay (سب سے پہلے), Awwal (اول)",
                urdu_sentence:
                  "Mulk badri ki muhim sab sai pehlay 2023 mein shuru ki gayi. (ملک بدری کی مہم سب سے پہلے 2023 میں شروع کی گئی۔)",
                pashto: "Awul (اول)",
                punjabi: "Pehla (پہلا)",
                sindhi: "Pariyon (پريون)",
                balochi: "Pajj (پاج)",
              },
              {
                word: "launched",
                usage_in_article: "A deportation drive first launched in 2023...",
                simple_english_meaning: "Started or set in motion (an activity or enterprise).",
                synonyms: ["commenced", "initiated", "began"],
                english_example: "The company launched its new product line in April.",
                urdu_meaning: "Shuru ki gayi (شروع کی گئی), Aaghaz kiya gaya (آغاز کیا گیا)",
                urdu_sentence:
                  "Mulk badri ki muhim pichlay saal shuru ki gayi thi. (ملک بدری کی مہم پچھلے سال شروع کی گئی تھی۔)",
                pashto: "Pīl Šaw (پیل شو)",
                punjabi: "Shuru Kiti Gayi (شروع کیتی گئی)",
                sindhi: "Shuru Kayo (شروع ڪيو)",
                balochi: "Band Kangan (بند کنگن)",
              },
              {
                word: "renewed",
                usage_in_article: "was renewed in April when the government...",
                simple_english_meaning: "Resumed or restarted (an activity) after an interruption.",
                synonyms: ["restarted", "resumed", "reinitiated"],
                english_example: "The license was renewed for another two years.",
                urdu_meaning: "Dobara shuru ki gayi (دوبارہ شروع کی گئی), Tajdeed ki gayi (تجدید کی گئی)",
                urdu_sentence:
                  "Mulk badri ki muhim April mein dobara shuru ki gayi. (ملک بدری کی مہم اپریل میں دوبارہ شروع کی گئی۔)",
                pashto: "Nawā Kawul (نوا کول)",
                punjabi: "Dōbārā Shuru Kiti (دوبارہ شروع کیتی)",
                sindhi: "Taajidid Kayo (تجديد ڪيو)",
                balochi: "Nawād Kangan (نود کنگن)",
              },
              {
                word: "rescinded",
                usage_in_article: "the government rescinded hundreds of thousands of residence permits...",
                simple_english_meaning: "Revoked, canceled, or repealed (a law, order, or agreement).",
                synonyms: ["revoked", "canceled", "annulled"],
                english_example: "The court rescinded the previous ruling after new evidence was presented.",
                urdu_meaning: "Mansookh karna (منسوخ کرنا), Wapas Laina (واپس لینا)",
                urdu_sentence:
                  "Hukumat nai afghano kay rehaishi permit mansookh kar diye. (حکومت نے افغانوں کے رہائشی پرمٹ منسوخ کر دیے۔)",
                pashto: "Mansūkh Kaṛal (منسوخ کړل)",
                punjabi: "Radd Kar Ditte (رد کر دِتے)",
                sindhi: "Radd Karan (رد ڪرڻ)",
                balochi: "Radd Kangan (رد کنگن)",
              },
              {
                word: "residence permits",
                usage_in_article: "rescinded hundreds of thousands of residence permits for Afghans",
                simple_english_meaning:
                  "Official documents allowing a foreign national to legally live in a country for an extended period.",
                synonyms: ["visa", "stay permit", "Green Card (US context)"],
                english_example: "He applied for a new residence permit after his old one expired.",
                urdu_meaning: "Iqaamati Permit (اقامتی پرمٹ), Rehaishi Ijazat Namay (رہائشی اجازت نامے)",
                urdu_sentence:
                  "Hukumat nai afghano kay liye lakhon iqaamati permit mansookh kiye. (حکومت نے افغانوں کے لیے لاکھوں اقامتی پرمٹ منسوخ کیے ہیں۔)",
                pashto: "Da Osīdo Ijāzat Līkunah (د اوسیدو اجازه لیکونه)",
                punjabi: "Rihā'ishi Pārmit (رہائشی پارمِٹ)",
                sindhi: "Rahāish Parmiṭ (رهائش پرمٽ)",
                balochi: "Ōtī Parmiṭ (اوتی پرمٹ)",
              },
              {
                word: "warning",
                usage_in_article: "warning them of arrests if they did not leave.",
                simple_english_meaning: "A statement or event that indicates a possible danger or problem.",
                synonyms: ["cautioning", "alerting", "threat"],
                english_example: "The weather service issued a warning about the approaching storm.",
                urdu_meaning: "Khabardar karna (خبردار کرنا), Tanbeeh (تنبیہ)",
                urdu_sentence:
                  "Hukumat nai khabardar kiya kay na janay ki soorat mein giriftari hogi. (حکومت نے خبردار کیا کہ نہ جانے کی صورت میں گرفتاری ہوگی۔)",
                pashto: "Akhpār Wawul (اخطار واوول)",
                punjabi: "Khabardar Karna (خبردار کرنا)",
                sindhi: "Ddarā'o (ڏراو)",
                balochi: "Darān (دران)",
              },
              {
                word: "arrests",
                usage_in_article: "warning them of arrests if they did not leave.",
                simple_english_meaning:
                  "The action of seizing someone by legal authority and taking them into custody.",
                synonyms: ["detentions", "apprehensions", "custody"],
                english_example: "The police made several arrests during the raid.",
                urdu_meaning: "Giriftariyan (گرفتاریاں), Pakarna (پکڑنا)",
                urdu_sentence:
                  "Unhain mulk na chornay ki soorat mein giriftariyon sai khabardar kiya gaya. (انہیں ملک نہ چھوڑنے کی صورت میں گرفتاریوں سے خبردار کیا گیا۔)",
                pashto: "Graftārī (گرفتاري)",
                punjabi: "Giraftāriyaan (گرفتاریاں)",
                sindhi: "Giraftāriyuon (گرفتاريون)",
                balochi: "Dōzāh Kangan (دوزاہ کنگن)",
              },
              {
                word: "analysts",
                usage_in_article: "Analysts say the expulsions are designed to pressure the Taliban...",
                simple_english_meaning:
                  "Experts who carefully examine and study information to provide explanations or interpretations.",
                synonyms: ["commentators", "experts", "pundits"],
                english_example: "Political analysts are predicting a close election.",
                urdu_meaning: "Tajziya Kaar (تجزیہ کار), Māhireen (ماہرین)",
                urdu_sentence:
                  "Tajziya karon ka kehna hai kay mulk badri siyasat sai mutaliq hai. (تجزیہ کاروں کا کہنا ہے کہ ملک بدری سیاست سے متعلق ہے۔)",
                pashto: "Šanūnkī (شنونکي)",
                punjabi: "Vishleshak (وشلیشک)",
                sindhi: "Tajzīya Nigār (تجزيہ نگار)",
                balochi: "Tajziya Kaar (تجزیہ کار)",
              },
              {
                word: "expulsions",
                usage_in_article: "Analysts say the expulsions are designed to pressure...",
                simple_english_meaning: "The action of forcing someone to leave a country.",
                synonyms: ["deportations", "removals", "evictions"],
                english_example: "The mass expulsions of refugees led to a humanitarian crisis.",
                urdu_meaning: "Ikhraj (اخراج), Mulk Badri (ملک بدری)",
                urdu_sentence:
                  "Tajziya karon ka kehna hai kay yeh ikhraj taliban par dabao dalnay kay liye hai. (تجزیہ کاروں کا کہنا ہے کہ یہ اخراج طالبان پر دباؤ ڈالنے کے لیے ہے۔)",
                pashto: "Īstal (ایستل)",
                punjabi: "Bēdakhli (بیدخلی)",
                sindhi: "Mulki Nikāli (ملڪي نيڪالي)",
                balochi: "Dar Kangan (در کنگن)",
              },
              {
                word: "designed",
                usage_in_article: "expulsions are designed to pressure the Taliban authorities...",
                simple_english_meaning: "Planned or intended for a particular purpose.",
                synonyms: ["intended", "aimed", "purposed"],
                english_example: "The new curriculum is designed to improve students' critical thinking skills.",
                urdu_meaning: "Mansuba bandi ki gayi (منصوبہ بندی کی گئی), Irada kiya gaya (ارادہ کیا گیا)",
                urdu_sentence:
                  "Mulk badri ka mansuba taliban par dabao dalnay kay liye banaya gaya. (ملک بدری کا منصوبہ طالبان پر دباؤ ڈالنے کے لیے بنایا گیا۔)",
                pashto: "Palan šawī (پلان شوي)",
                punjabi: "Mansūba Banāya (منصوبہ بنایا)",
                sindhi: "Dizā'īn Kayo (ڊيزائن ڪيو)",
                balochi: "Mansuba Kangan (منصوبہ کنگن)",
              },
              {
                word: "pressure",
                usage_in_article: "expulsions are designed to pressure the Taliban authorities...",
                simple_english_meaning: "To attempt to persuade or coerce someone into doing something.",
                synonyms: ["coerce", "compel", "urge"],
                english_example: "The opposition party continues to pressure the government for reform.",
                urdu_meaning: "Dabao Dalna (دباؤ ڈالنا), Majboor Karna (مجبور کرنا)",
                urdu_sentence:
                  "Mulk badri ka maqsad Afghanistan mein hukam par dabao dalna hai. (ملک بدری کا مقصد افغانستان میں حکام پر دباؤ ڈالنا ہے۔)",
                pashto: "Fišār Āchawul (فشار اچول)",
                punjabi: "Dabā'o Paana (دباؤ پانا)",
                sindhi: "Dabā'o Vajhan (دٻاءُ وجهڻ)",
                balochi: "Fišār Kangan (فشار کنگن)",
              },
              {
                word: "authorities",
                usage_in_article: "to pressure the Taliban authorities in Afghanistan...",
                simple_english_meaning:
                  "The people or organizations having the power or right to give orders, make decisions, and enforce obedience.",
                synonyms: ["government", "administration", "rulers"],
                english_example: "The local authorities are responsible for public safety.",
                urdu_meaning: "Hukam (حکام), Intizamia (انتظامیہ)",
                urdu_sentence:
                  "Tajziya kaar Taliban hukam kay sakht radd-e-amal ki tawaqqa kar rahay hain. (تجزیہ کار طالبان حکام کے سخت ردعمل کی توقع کر رہے ہیں۔)",
                pashto: "Chārwāki (چارواکي)",
                punjabi: "Athārti (اتھارٹی)",
                sindhi: "Hukūmati Idāra (حڪومتي ادارا)",
                balochi: "Hākim (حاکم)",
              },
            ],
          },
        }

        setArticleTitle(completeArticleData.article_title)
        setWords(completeArticleData.part1.vocabulary)
      } catch (error) {
        console.error("Error loading data:", error)
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [params.article])

  const handleMouseDown = (e: React.MouseEvent) => {
    if (zoomLevel > 1) {
      setIsDragging(true)
      setDragStart({ x: e.clientX - position.x * dragSpeed, y: e.clientY - position.y * dragSpeed })
    }
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      setPosition({
        x: (e.clientX - dragStart.x) / dragSpeed,
        y: (e.clientY - dragStart.y) / dragSpeed,
      })
    }
  }

  const handleMouseUp = () => {
    setIsDragging(false)
  }

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault()
    const delta = e.deltaY > 0 ? 0.9 : 1.1
    const newZoom = Math.min(Math.max(zoomLevel * delta, 1), 1000)
    if (newZoom === 1) {
      setPosition({ x: 0, y: 0 })
    }
    setZoomLevel(newZoom)
  }

  const getTouchDistance = (touches: TouchList) => {
    if (touches.length < 2) return 0
    const dx = touches[0].clientX - touches[1].clientX
    const dy = touches[0].clientY - touches[1].clientY
    return Math.sqrt(dx * dx + dy * dy)
  }

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      setTouchDistance(getTouchDistance(e.touches))
    } else if (e.touches.length === 1 && zoomLevel > 1) {
      setIsTouchDragging(true)
      setTouchDragStart({
        x: e.touches[0].clientX - position.x * dragSpeed,
        y: e.touches[0].clientY - position.y * dragSpeed,
      })
    }
  }

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 2 && touchDistance > 0) {
      const newDistance = getTouchDistance(e.touches)
      const delta = newDistance / touchDistance
      const newZoom = Math.min(Math.max(zoomLevel * delta, 1), 1000)
      setZoomLevel(newZoom)
      setTouchDistance(newDistance)
    } else if (e.touches.length === 1 && isTouchDragging) {
      setPosition({
        x: (e.touches[0].clientX - touchDragStart.x) / dragSpeed,
        y: (e.touches[0].clientY - touchDragStart.y) / dragSpeed,
      })
    }
  }

  const handleTouchEnd = () => {
    setTouchDistance(0)
    setIsTouchDragging(false)
  }

  return (
    <main className="min-h-screen bg-background flex flex-col">
      <div className="p-4 border-b border-border">
        <Link
          href={`/newspapers/${params.newspaper}/months/${params.month}/dates/${params.date}/categories/${params.category}/articles`}
          className="inline-flex items-center text-primary hover:text-primary/80 transition"
        >
          ← Back to Articles
        </Link>
      </div>

      {articleTitle && (
        <div className="px-6 pt-4 pb-2">
          <h1 className="text-2xl font-bold text-foreground">{articleTitle}</h1>
        </div>
      )}

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-6 p-6 overflow-hidden">
        {/* Image Viewer - Top/Left */}
        <div className="flex flex-col gap-4">
          <motion.div
            ref={imageContainerRef}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="bg-card rounded-lg border border-border overflow-hidden flex items-center justify-center flex-1"
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            onWheel={handleWheel}
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
          >
            {loading ? (
              <div className="text-center py-12">
                <p className="text-muted-foreground">Loading newspaper...</p>
              </div>
            ) : (
              <div className="relative w-full h-full overflow-hidden">
                <motion.img
                  src={imageUrl}
                  alt={articleTitle || "Newspaper"}
                  className={`w-full h-full object-cover ${isTouchDragging || isDragging ? "cursor-grabbing" : "cursor-grab"}`}
                  style={{
                    transform: `scale(${zoomLevel}) translate(${position.x}px, ${position.y}px)`,
                    transformOrigin: "center",
                    transition: isDragging || isTouchDragging ? "none" : "transform 0.2s",
                  }}
                />
                {zoomLevel > 1 && (
                  <div className="absolute bottom-4 right-4 text-xs bg-background/80 px-2 py-1 rounded text-muted-foreground">
                    {Math.round(zoomLevel * 100)}%
                  </div>
                )}
              </div>
            )}
          </motion.div>

          {zoomLevel > 1 && (
            <div className="bg-card rounded-lg border border-border p-4">
              <div className="flex items-center gap-4">
                <label className="text-sm font-medium text-foreground">Drag Speed:</label>
                <input
                  type="range"
                  min="0.5"
                  max="2"
                  step="0.1"
                  value={dragSpeed}
                  onChange={(e) => setDragSpeed(Number.parseFloat(e.target.value))}
                  className="flex-1 h-2 bg-secondary rounded-lg appearance-none cursor-pointer"
                />
                <span className="text-sm font-semibold text-primary w-12 text-right">{dragSpeed.toFixed(1)}x</span>
              </div>
            </div>
          )}
        </div>

        {/* Words List - Bottom/Right */}
        <div className="flex flex-col h-full overflow-hidden">
          <h2 className="text-2xl font-bold text-foreground mb-4">Vocabulary</h2>
          <div className="flex-1 overflow-y-auto overflow-x-hidden space-y-3 pr-3">
            {words.length === 0 ? (
              <p className="text-muted-foreground">No vocabulary items available.</p>
            ) : (
              <>
                <p className="text-xs text-muted-foreground sticky top-0 bg-background/50 backdrop-blur py-2">
                  Showing {words.length} vocabulary words
                </p>
                {words.map((word, idx) => (
                  <motion.button
                    key={`${word.word}-${idx}`}
                    onClick={() => setSelectedWord(word)}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.02 }}
                    whileHover={{ scale: 1.02, x: 10 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full p-4 bg-card rounded-lg border border-border hover:border-primary/50 hover:bg-card/80 transition-all text-left"
                  >
                    <p className="font-semibold text-foreground">{word.word}</p>
                    <p className="text-sm text-muted-foreground line-clamp-2">{word.simple_english_meaning}</p>
                  </motion.button>
                ))}
              </>
            )}
          </div>
        </div>
      </div>

      <TranslationModal word={selectedWord} onClose={() => setSelectedWord(null)} />
    </main>
  )
}
