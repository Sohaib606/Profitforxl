"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { useParams } from "next/navigation"
import { motion } from "framer-motion"
import Link from "next/link"
import { TranslationModal } from "@/components/translation-modal"

interface WordData {
  word: string
  usage_in_article: string
  simple_english_meaning: string
  synonyms: string[]
  english_example: string
  urdu_meaning: string
  urdu_sentence: string
  pashto: string
  punjabi: string
  sindhi: string
  balochi?: string
}

interface ArticleData {
  article_title: string
  part1: {
    vocabulary: WordData[]
  }
  part2: {
    terms: Array<{
      term: string
      simple_english_explanation: string
      background: string
      relevance_to_article: string
    }>
  }
}

export default function ViewerPage() {
  const params = useParams()
  const [words, setWords] = useState<WordData[]>([])
  const [selectedWord, setSelectedWord] = useState<WordData | null>(null)
  const [loading, setLoading] = useState(true)
  const [imageUrl, setImageUrl] = useState(
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/02_08_2025_001_001-NC3u3qgY4t7qht2GdLZtrEVjqvzylW.jpg",
  )
  const [articleTitle, setArticleTitle] = useState("")
  const [zoomLevel, setZoomLevel] = useState(1)
  const [position, setPosition] = useState({ x: 0, y: 0 })
  const [isDragging, setIsDragging] = useState(false)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })
  const [touchDistance, setTouchDistance] = useState(0)
  const [isTouchDragging, setIsTouchDragging] = useState(false)
  const [touchDragStart, setTouchDragStart] = useState({ x: 0, y: 0 })
  const [dragSpeed, setDragSpeed] = useState(1)
  const imageContainerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const loadData = async () => {
      try {
        // For now, using hardcoded example data structure
        const articleData: ArticleData = {
          article_title: "Govt issues fresh call for Afghans to leave",
          part1: {
            vocabulary: [
              {
                word: "issues",
                usage_in_article: "Govt issues fresh call...",
                simple_english_meaning:
                  "To formally send out or announce something, like a warning, statement, or command.",
                synonyms: ["releases", "publishes", "announces"],
                english_example: "The central bank issues new currency notes every few years.",
                urdu_meaning: "Jari Karna (جاری کرنا), Hukm Nama Jari Karna (حکم نامہ جاری کرنا)",
                urdu_sentence:
                  "Hukumat nai afghano ko mulk chornay kay liye naya hukm nama jari kiya hai. (حکومت نے افغانوں کو ملک چھوڑنے کے لیے نیا حکم نامہ جاری کیا ہے۔)",
                pashto: "Khparawul (خپرول)",
                punjabi: "Jari Karna (جاری کرنا)",
                sindhi: "Jari Karan (جاري ڪرڻ)",
                balochi: "Shuroo Kangan (شروع کنگن)",
              },
              {
                word: "fresh",
                usage_in_article: "Govt issues fresh call...",
                simple_english_meaning: "New or different, in addition to what has existed before.",
                synonyms: ["new", "additional", "latest"],
                english_example: "The government announced a fresh set of economic reforms.",
                urdu_meaning: "Naya (نیا), Taza (تازہ)",
                urdu_sentence:
                  "Aik taza muhim jald hi mulk bhar mein shuru ki jaye gi. (ایک تازہ مہم جلد ہی ملک بھر میں شروع کی جائے گی۔)",
                pashto: "Nawae (نوی)",
                punjabi: "Nawan (نواں)",
                sindhi: "Naoon (نئون)",
                balochi: "Nok (نوک)",
              },
              {
                word: "call",
                usage_in_article: "Govt issues fresh call for Afghans to leave...",
                simple_english_meaning: "A formal public request or command.",
                synonyms: ["demand", "appeal", "directive"],
                english_example: "The environmental group issued a call for immediate action.",
                urdu_meaning: "Mutalba (مطالبہ), Hukm (حکم), Daawat (دعوت)",
                urdu_sentence:
                  "Wazarat-e-Dakhila nai shehriyon sai razakarana tor par mulk chornay ka mutalba kiya hai. (وزارت داخلہ نے شہریوں سے رضاکارانہ طور پر ملک چھوڑنے کا مطالبہ کیا ہے۔)",
                pashto: "Ghoṣtana (غوښتنه)",
                punjabi: "Mang (منگ)",
                sindhi: "Sadd (سڏ)",
                balochi: "Talab (طلب)",
              },
            ],
          },
          part2: {
            terms: [],
          },
        }

        setArticleTitle(articleData.article_title)
        setWords(articleData.part1.vocabulary)
      } catch (error) {
        console.error("Error loading data:", error)
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [params.date, params.category])

  const handleMouseDown = (e: React.MouseEvent) => {
    if (zoomLevel > 1) {
      setIsDragging(true)
      setDragStart({ x: e.clientX - position.x * dragSpeed, y: e.clientY - position.y * dragSpeed })
    }
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      setPosition({
        x: (e.clientX - dragStart.x) / dragSpeed,
        y: (e.clientY - dragStart.y) / dragSpeed,
      })
    }
  }

  const handleMouseUp = () => {
    setIsDragging(false)
  }

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault()
    const delta = e.deltaY > 0 ? 0.9 : 1.1
    const newZoom = Math.min(Math.max(zoomLevel * delta, 1), 1000)
    if (newZoom === 1) {
      setPosition({ x: 0, y: 0 })
    }
    setZoomLevel(newZoom)
  }

  const getTouchDistance = (touches: TouchList) => {
    if (touches.length < 2) return 0
    const dx = touches[0].clientX - touches[1].clientX
    const dy = touches[0].clientY - touches[1].clientY
    return Math.sqrt(dx * dx + dy * dy)
  }

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      setTouchDistance(getTouchDistance(e.touches))
    } else if (e.touches.length === 1 && zoomLevel > 1) {
      setIsTouchDragging(true)
      setTouchDragStart({
        x: e.touches[0].clientX - position.x * dragSpeed,
        y: e.touches[0].clientY - position.y * dragSpeed,
      })
    }
  }

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 2 && touchDistance > 0) {
      const newDistance = getTouchDistance(e.touches)
      const delta = newDistance / touchDistance
      const newZoom = Math.min(Math.max(zoomLevel * delta, 1), 1000)
      setZoomLevel(newZoom)
      setTouchDistance(newDistance)
    } else if (e.touches.length === 1 && isTouchDragging) {
      setPosition({
        x: (e.touches[0].clientX - touchDragStart.x) / dragSpeed,
        y: (e.touches[0].clientY - touchDragStart.y) / dragSpeed,
      })
    }
  }

  const handleTouchEnd = () => {
    setTouchDistance(0)
    setIsTouchDragging(false)
  }

  return (
    <main className="min-h-screen bg-background flex flex-col">
      <div className="p-4 border-b border-border">
        <Link
          href={`/newspapers/${params.newspaper}/months/${params.month}/dates/${params.date}/categories`}
          className="inline-flex items-center text-primary hover:text-primary/80 transition"
        >
          ← Back to Categories
        </Link>
      </div>

      {articleTitle && (
        <div className="px-6 pt-4 pb-2">
          <h1 className="text-2xl font-bold text-foreground">{articleTitle}</h1>
        </div>
      )}

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-6 p-6 overflow-hidden">
        {/* Image Viewer - Top/Left */}
        <div className="flex flex-col gap-4">
          <motion.div
            ref={imageContainerRef}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="bg-card rounded-lg border border-border overflow-hidden flex items-center justify-center flex-1"
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            onWheel={handleWheel}
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
          >
            {loading ? (
              <div className="text-center py-12">
                <p className="text-muted-foreground">Loading newspaper...</p>
              </div>
            ) : (
              <div className="relative w-full h-full overflow-hidden">
                <motion.img
                  src={imageUrl}
                  alt={articleTitle || "Newspaper"}
                  className={`w-full h-full object-cover ${isTouchDragging || isDragging ? "cursor-grabbing" : "cursor-grab"}`}
                  style={{
                    transform: `scale(${zoomLevel}) translate(${position.x}px, ${position.y}px)`,
                    transformOrigin: "center",
                    transition: isDragging || isTouchDragging ? "none" : "transform 0.2s",
                  }}
                />
                {zoomLevel > 1 && (
                  <div className="absolute bottom-4 right-4 text-xs bg-background/80 px-2 py-1 rounded text-muted-foreground">
                    {Math.round(zoomLevel * 100)}%
                  </div>
                )}
              </div>
            )}
          </motion.div>

          {zoomLevel > 1 && (
            <div className="bg-card rounded-lg border border-border p-4">
              <div className="flex items-center gap-4">
                <label className="text-sm font-medium text-foreground">Drag Speed:</label>
                <input
                  type="range"
                  min="0.5"
                  max="2"
                  step="0.1"
                  value={dragSpeed}
                  onChange={(e) => setDragSpeed(Number.parseFloat(e.target.value))}
                  className="flex-1 h-2 bg-secondary rounded-lg appearance-none cursor-pointer"
                />
                <span className="text-sm font-semibold text-primary w-12 text-right">{dragSpeed.toFixed(1)}x</span>
              </div>
            </div>
          )}
        </div>

        {/* Words List - Bottom/Right */}
        <div className="flex flex-col">
          <h2 className="text-2xl font-bold text-foreground mb-4">Vocabulary</h2>
          <div className="flex-1 overflow-y-auto space-y-3">
            {words.length === 0 ? (
              <p className="text-muted-foreground">No vocabulary items available.</p>
            ) : (
              words.map((word, idx) => (
                <motion.button
                  key={word.word}
                  onClick={() => setSelectedWord(word)}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  whileHover={{ scale: 1.02, x: 10 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full p-4 bg-card rounded-lg border border-border hover:border-primary/50 hover:bg-card/80 transition-all text-left"
                >
                  <p className="font-semibold text-foreground">{word.word}</p>
                  <p className="text-sm text-muted-foreground">{word.simple_english_meaning.substring(0, 60)}...</p>
                </motion.button>
              ))
            )}
          </div>
        </div>
      </div>

      <TranslationModal word={selectedWord} onClose={() => setSelectedWord(null)} />
    </main>
  )
}
