"use client"

import { useRouter, useParams } from "next/navigation"
import { motion } from "framer-motion"
import Link from "next/link"

export default function MonthsPage() {
  const router = useRouter()
  const params = useParams()

  // Generate months for the current year and previous year
  const months = [
    { name: "October 2025", value: "2025-10" },
    { name: "September 2025", value: "2025-09" },
    { name: "August 2025", value: "2025-08" },
    { name: "July 2025", value: "2025-07" },
    { name: "June 2025", value: "2025-06" },
    { name: "May 2025", value: "2025-05" },
    { name: "April 2025", value: "2025-04" },
    { name: "March 2025", value: "2025-03" },
    { name: "February 2025", value: "2025-02" },
    { name: "January 2025", value: "2025-01" },
  ]

  return (
    <main className="min-h-screen bg-background p-6">
      <div className="max-w-4xl mx-auto">
        <Link href="/" className="inline-flex items-center text-primary hover:text-primary/80 mb-8 transition">
          ← Back
        </Link>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl font-bold text-foreground mb-2"
        >
          Select Month
        </motion.h1>
        <p className="text-muted-foreground mb-12">Choose a month to browse available editions</p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {months.map((month, idx) => (
            <motion.button
              key={month.value}
              onClick={() => router.push(`/newspapers/${params.newspaper}/months/${month.value}/dates`)}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="p-6 bg-card rounded-lg border border-border hover:border-primary/50 hover:shadow-md transition-all text-center"
            >
              <p className="text-lg font-semibold text-foreground">{month.name}</p>
            </motion.button>
          ))}
        </div>
      </div>
    </main>
  )
}
